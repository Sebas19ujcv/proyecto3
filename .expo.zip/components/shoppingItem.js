import { Pressable, ProgressBarAndroidComponent, StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { AntDesign, MaterialIcons  } from '@expo/vector-icons';
import {db,doc, updateDoc, deleteDoc} from "../firebase/index";

// shopping object
/*
1. id
2. title
3. isChecked


*/
const shoppingsItem = (props)=> {
    const [isChecked,setIschecked] = useState(props.isChecked);

    const updateIsChecked = async() => {
        const shoppingRef = doc(db, "shopping", props.id);

// Set the "capital" field of the city 'DC'
await updateDoc(shoppingRef, {
  isChecked: isChecked,
});
    };
const deleteShoppingItem = async() => {

    await deleteDoc(doc(db, "shopping", props.id));
    props.getShoppingList();
}

useEffect(()=>{
    updateIsChecked();
},[isChecked]);

    return (
    <View Style={styles.container}>
    {/* checked icon */}
    <Pressable onPress={()=>setIschecked(!isChecked)}>
        
            {isChecked ?  (
            <AntDesign name="checkcircle" size={24} color="black" /> 
            ):(
<AntDesign name="checkcircleo" size={24} color="black" />
            )}
        </Pressable>

        {/* Shooping text */}
        <Text style={styles.tittle}>{props.title}</Text>
            {/* delete button */}
            <Pressable onPress={deleteShoppingItem}>
            <MaterialIcons name="delete" size={24} color="black" />
            </Pressable>
    </View>
    );
};

export default shoppingsItem;

const styles = StyleSheet.create({
    container:{
     flexDirection: "row",
     backgroundColor: "red",
     justifyContent: "space-between",
     padding: 10,
     alignContent: "center",
     width: "90%",
     alignSelf: "center",
     borderRadius: 10,
    },
    title: {
        flex: 1,
        marginLeft: 10,
        fontSize: 17,
        fontWeight: "500",
        marginVertical: 10,
    },
});



