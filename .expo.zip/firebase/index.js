// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { initializeApp } from "firebase/app";
import { getFirestore,collection, addDoc, getDocs, updateDoc, deleteDoc } from "firebase/firestore";


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAFzPqHzcbSmcoB_gnj-TZupBEH0vijKXo",
  authDomain: "proyectofirebase-3130a.firebaseapp.com",
  projectId: "proyectofirebase-3130a",
  storageBucket: "proyectofirebase-3130a.appspot.com",
  messagingSenderId: "964542624342",
  appId: "1:964542624342:web:84de8ecbed50c1f91581f7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export {app,db,getFirestore,collection, addDoc, getDocs, doc, updateDoc, deleteDoc}
